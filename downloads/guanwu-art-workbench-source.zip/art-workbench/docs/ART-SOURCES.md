# 美术、字体与研究依据

## 网页中的原创研究图

- `src/assets/landscape.png`：2026-10-03 生成辅助的青绿山水、南宋小景、敦煌设色研究板。源文件 SHA-256 为 `f6ad47f4978cd9bbf9dcbb6c32654b7984946663cba6f9cf539c570247c7e2bb`。
- `src/assets/forms.png`：同日生成并修订的人物、器物与造型语言研究板。修订源文件 SHA-256 为 `b571506306fc7dc770af9ef3ae0d26385f25519503af52b2349e084895520c2a`。

两图使用 image_gen 按本项目原创研究简报生成，没有用馆藏图进行编辑、裁切或拼贴。页面以 CSS 展示研究板的局部，不改变源文件。图像是现代转译示意，不是博物馆对象、历史服饰或建筑复原；不同路线有时借用相近的形式示意，不能将配图作为实物证据。

## 深研室的互动结构图

深研室中的山水空间、器物轮廓与线色组织图由项目代码绘制为原创 SVG。它们使用简化几何与现代参考色，随路线和滑块改变，用于比较尺度、开放区、主次明度、口腹关系、装饰覆盖或图文层次。没有将馆藏图像描摹为 SVG，也没有读取文物或古画的几何测量数据。

滑块起点和百分比是本项目的实验设定，不是古代比例标准、艺术史测量、颜料分析或文物复原结论。灰阶视图与结构辅助线作用于同一现代示意；是否采用 A 或 B、为什么采用，都由使用者人工判断并记录。

## 字体

`Guanwu Serif` 是本项目对 Google Fonts 公开发布的 Noto Serif SC 的衍生子集，固定字重 400，并重新命名字体族。原始文件来自 `google/fonts` 官方仓库：

https://raw.githubusercontent.com/google/fonts/main/ofl/notoserifsc/NotoSerifSC%5Bwght%5D.ttf

原始 SHA-256：`050080d9255a86808f2945bffac582b31ef32bc36411ce29563b4961670c66f9`。

网页包含修改后的 WOFF2 字体；来源、哈希与修改方式在 `src/assets/font-provenance.json`。字体采用 SIL Open Font License 1.1，以下保留原始许可证全文。正文和用户新输入也可使用系统中文字体。

## 文献与馆藏线索

具体作品和书目在 `src/data/traditions.ts`，对照档案在 `src/data/dossiers.ts`，研究方法在 [research-method.md](research-method.md)。第二版实际读取了故宫博物院、台北故宫数字典藏与数字敦煌的具体官方条目，核对 12 个条目，其中 11 个对应现有 37 条研究来源；另一件永乐压手杯只作防止混件的比较，不新增核心来源。准确页面、核对时间、字段与限制见 [evidence-audit.md](evidence-audit.md)。未核对的来源继续保留 `reference`；来源条目的最终状态以随源码交付的数据为准。

核对的是馆方记录所述的名称、时代、媒介、尺寸和作品说明，不是独立鉴定作者与年代，也不自动确证每项结构分析或现代制作假设。未下载、打包或再分发此次核验的馆藏照片和官方网页全文，只保留事实摘要、必要短引与可追溯链接。

台北故宫数字典藏页面所述的网站资料开放范围与署名要求已在核验记录中区分。涉及该站资料时，来源为“国立故宫博物院，台北，CC BY 4.0 @ www.npm.gov.tw”，具体作品与入口见各条记录。网站文字的声明、某规格图像的许可和馆藏实物本身不是同一授权，不能据此把所有馆藏照片变成可直接用于发行的素材。

制作期间可实际读取大都会艺术博物馆官方 GitHub 开放数据说明：

https://github.com/metmuseum/openaccess

其 README 获取成功，仅用于了解数据与图像权利的区别，不能证明上述具体中国艺术条目已经核验。本网页未打包或再分发该馆藏数据与图片。

参考颜色是现代数字制作起点，不是历史颜料的科学复原值。本文没有为被引用的馆藏图片重新授予使用许可。研究笔记中的出处核验状态、使用者勾选的审校项与最终图片授权分别记录，不能互相替代。

## 字体原始许可证

Copyright 2012 Google Inc. All Rights Reserved.

This Font Software is licensed under the SIL Open Font License,
Version 1.1.

This license is copied below, and is also available with a FAQ at:
http://scripts.sil.org/OFL

-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font
creation efforts of academic and linguistic communities, and to
provide a free and open framework in which fonts may be shared and
improved in partnership with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply to
any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software
components as distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to,
deleting, or substituting -- in part or in whole -- any of the
components of the Original Version, by changing formats or by porting
the Font Software to a new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed,
modify, redistribute, and sell modified and unmodified copies of the
Font Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components, in
Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the
corresponding Copyright Holder. This restriction only applies to the
primary font name as presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created using
the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
